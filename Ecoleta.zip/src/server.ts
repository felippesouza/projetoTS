import express from 'express';
import path from 'path';
import routes from './routes';
import cors from 'cors';

const app = express()

app.use(cors());
app.use(express.json());
app.use(routes);
app.use('/uploads', express.static(path.resolve(__dirname, '..', 'uploads')));

//Rota = Endereço completo da requisição
//Recurso = Qual entidade estamos acessando do sistema

//Get = buscar uma ou mais informações do back-end
//Post = Criar uma nova informção no back-end
//Put = Atualizar uma informação exitente do back-end
//delete = deletar uma informação do back-end

//POST http://localhost:3333/users = Criar um usuário
//GET  http://localhost:3333/users = Listar usuarios
//GET  http://localhost:3333/users/5 = Buscar dados de um usuário com ID 5

//Request Param: Parametros que vem na propria rota que identificam um recurso
//Query param: São parametros que vem na propria rota, geralmente opcionais para filtros, paginacao e etc.
//Request body: São parametros para criação e atualizacao de informações.

//Comando para utilizar o banco de dados:
//Normal do SQL = SELECT * FROM users WHERE name = 'Diego'
//usando KNEX = knex('users').where('name', 'Felippe').select('*')

//comando de start = npm run dev

app.listen(3333);